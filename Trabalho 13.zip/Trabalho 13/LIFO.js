//const prompt = require('prompt-sync')();

// FUNÇÃO DE MENSAGEM
function message(msg, timems = 2000) {
    console.log("\n" + msg);
    sleep(timems);
}

// FUNÇÃO SLEEP
function sleep(ms) {
    const start = Date.now();

    while (Date.now() - start < ms) {
        // espera
    }
}

// CLASSE PILHA
class Stack {
    constructor() {
        this.items = [];
    }

    // Adiciona elemento no topo
    push(element) {
        this.items.push(element);
    }

    // Remove elemento do topo
    pop() {
        if (this.isEmpty()) {
            return undefined;
        }

        return this.items.pop();
    }

    // Mostra o topo
    peek() {
        if (this.isEmpty()) {
            return undefined;
        }

        return this.items[this.items.length - 1];
    }

    // Verifica se está vazia
    isEmpty() {
        return this.items.length === 0;
    }

    // Tamanho da pilha
    size() {
        return this.items.length;
    }

    // Limpa a pilha
    clear() {
        this.items = [];
    }

    // Exibe elementos
    toString() {
        return this.items.join(" -> ");
    }
}

// MAIN
let historico = new Stack();
historico.push(0); // valor inicial da calculadora

let option;
let valorAtual = 0;

do {
    console.clear();

    console.log("=================================");
    console.log("           CALCULADORA     ");
    console.log("=================================\n");

    console.log("Resultado atual: " + valorAtual + "\n");

    console.log("1 - Somar");
    console.log("2 - Subtrair");
    console.log("3 - Desfazer última operação");
    console.log("4 - Mostrar histórico");
    console.log("9 - Sair\n");

    option = parseInt(prompt("Escolha uma opção: "));

    switch (option) {

        case 1:
            let soma = parseFloat(prompt("Digite o valor para somar: "));

            valorAtual += soma;

            historico.push(valorAtual);

            message("Operação realizada!");
            break;

        case 2:
            let sub = parseFloat(prompt("Digite o valor para subtrair: "));

            valorAtual -= sub;

            historico.push(valorAtual);

            message("Operação realizada!");
            break;

        case 3:

            if (historico.size() > 1) {

                historico.pop();

                valorAtual = historico.peek();

                message("Última operação desfeita!");
            } else {

                valorAtual = 0;

                message("Nenhuma operação para desfazer!");
            }

            break;

        case 4:

            console.log("\nHistórico da pilha:");
            console.log(historico.toString());

            prompt("\nPressione ENTER para continuar...");
            break;

        case 9:
            console.clear();
            console.log("Calculadora encerrada!");
            break;

        default:
            message("Opção inválida!");
    }

} while (option !== 9);
